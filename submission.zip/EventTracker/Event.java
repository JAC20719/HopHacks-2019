//Event.java
//A parent class different types of events

package EventTracker;

import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Scanner;



public class Event {

    //title of event
    private static String title;

    //author of event
    private static String creator;

    //date of event
    private static String date;
    
    //starting time and ending time
    private static String start;
    private static String end;

    //description of event
    private static String description;

    //location of event
    private static String location;

    //unique identifier of event
    private static int eventID;
    
    //type of event
    /*
      Study   -  (0)
      Sports  -  (1)
      Gaming  -  (2)
      Hangout -  (3)
    */

    private static int type;
    
    //list of people's ID's who are going to event
    private static ArrayList<Integer> attendees = new ArrayList<Integer>();

    //number of attendees;
    private static int numAttendees;
        
    //input event database
    private static FileInputStream input;

    //output event database
    private static FileOutputStream eventOutput;

    //number of events database
    private static FileOutputStream numOutput;

    //scanner of input
    private static Scanner scanner;

    //printer to output
    private static PrintWriter printer;

    //printer to numEvents
    private static PrintWriter numPrinter;

    //current ID
    private static int currentID = 0;

    //Type Name
    private static String typeName;


    Event(String aTitle, String aCreator, String aDate, String aStart, String aEnd, String aDescription, String aLocation, int aType) throws IOException{

	Event.title = aTitle;
	Event.creator = aCreator;
	Event.date = aDate;
	Event.start = aStart;
	Event.end = aEnd;
	Event.description = aDescription;
	Event.location = aLocation;
	Event.type = aType;
        Event.attendees = new ArrayList<Integer>();
	Event.numAttendees = 0;
	
	createNewEventFile();
    }

    private static void createNewEventFile() throws IOException{

	Event.input = new FileInputStream("numEvents.txt");
	Event.scanner = new Scanner(input);
	Event.currentID = scanner.nextInt();
	Event.eventID = currentID;

	printToFile(Event.eventID);
	
	Event.numOutput = new FileOutputStream("numEvents.txt", false);
	Event.numPrinter = new PrintWriter(numOutput);

	Event.numPrinter.print(++Event.currentID);
	
	Event.numPrinter.flush();
	Event.numPrinter.close();

	
	Event.scanner.close();
    }


    public static void printToFile(int ID) throws IOException{
	
	String temporary = ("event" + ID + ".txt");

	Event.eventOutput = new FileOutputStream(temporary);
	Event.printer = new PrintWriter(eventOutput);

	printer.printf("%s\n %s\n%s %s %s %s\n%s\n%d %d %d ", Event.title, Event.creator, Event.date, Event.start, Event.end, Event.description, Event.location, Event.type, Event.eventID, Event.numAttendees);
	if(Event.numAttendees > 0) {
	    for(int i = 0; i < numAttendees; i++){
		Event.printer.printf("%d ", Event.attendees.get(i));
	    }
	    
	}

	Event.printer.flush();
	Event.printer.close();
    }

    //adds userID a to list of attendees
    public static void addMember(int a, int b) throws IOException{
	String temp = "event" + a + ".txt";
	FileInputStream fun = new FileInputStream(temp);;
	readIn(fun);
	Event.attendees.add(b);
	Event.numAttendees++;
	Event.printToFile(a);
    }

    private static void readIn(FileInputStream input) {

	Scanner eventScan = new Scanner(input);
	
	Event.title = eventScan.nextLine();
	Event.creator = eventScan.nextLine();
	Event.date = eventScan.next();
	Event.start = eventScan.next();
	Event.end = eventScan.next();
	Event.description = eventScan.nextLine();
	Event.location = eventScan.nextLine();
	Event.type = eventScan.nextInt();
	Event.eventID = eventScan.nextInt();
	Event.numAttendees = eventScan.nextInt();

	if(Event.numAttendees > 0){
	    for(int i = 0; i < Event.numAttendees; i++){
		Event.attendees.add(eventScan.nextInt());
	    }
	}
	eventScan.close();
    }

    private static boolean typeChecker(String file, int category) throws IOException {
	FileInputStream daFile = new FileInputStream(file);
	Scanner checker = new Scanner(daFile);
	String clear = "";
	for(int i = 0; i < 4; i++) {
	    clear = checker.nextLine();
	}
	if(checker.nextInt() == category) {
	    checker.close();
	    return true;
	} else {
	    checker.close();
	    return false;
	}
    }
    
    public static void exploreEvent(int category, ArrayList<Integer> edits ) throws IOException {
	
	FileInputStream hi;

	try{
	    hi = new FileInputStream("numEvents.txt");
	}
	catch(FileNotFoundException e){
	    System.out.println("Missing resources:  make clean");
	    return;
	}

	Scanner getID = new Scanner(hi);
	Event.currentID = getID.nextInt();

	getID.close();


	
	String temp = "";
	for(int i = 0; i < Event.currentID; i++ ) {
	    temp = "event" + i + ".txt";
	    if(typeChecker(temp, category)) {
		edits.add(i);
	    }
	}
    }

    public static String returnString(int ID) throws FileNotFoundException{
	
	String temp;
	System.out.println(currentID + "\n");
	FileInputStream meHelp = new FileInputStream("numEvents.txt");
	Scanner helpMe = new Scanner(meHelp);
	Event.currentID = helpMe.nextInt();
	helpMe.close();
	if(ID <= Event.currentID){
	    temp = ("event" + ID + ".txt");
	    FileInputStream input = new FileInputStream(temp);
	    readIn(input);
	    
	    temp =  "Title: " + Event.title + "\nCreator: " + Event.creator + "\nDate: " + Event.date
		+ "\nStarting Time: " + Event.start + "\nEnding Time: " + Event.end + "\nDescription: "
		+ Event.description + "\nLocation: " + Event.location + "\nType: " + getType()
		+ "\nUnique Identifier: " + Event.getID();
	    
	}else{
	    return "invalid event ID";
	    
	}
	return temp;
    }

    public static String getType() {
	
	switch(Event.type){
	    
	case 1:
	    Event.typeName = "Study";
	    break;
	case 2:
	    Event.typeName = "Clubs";
	    break;
	case 3:
	    Event.typeName = "Video Games";
	    break;
	case 4:
	    Event.typeName = "Food";
	    break;
	case 5:
	    Event.typeName = "Social";
	    break;	
	default:
	    Event.typeName = "NaN";
	}
	return Event.typeName;
    }

    public static int getID(){
	return eventID;
    }
        
}





