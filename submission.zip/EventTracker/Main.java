//Main.java
//the file used to run the user interface

package EventTracker;

import java.io.IOException;
import java.io.FileNotFoundException;

import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    
    static Scanner scan = new Scanner(System.in);

    static boolean validInput = false;
    static boolean validUser = false;
    static boolean validSchool = false;
    static String username = "";
    static String password = "";
    static String email = "";
    static String name = "";
    static int school = 0;
    
    static int entry = -1;
    
    static int choice = 0;
    static int state = 1;
    static boolean done = false;


    //variables when adding an event 
    static String title;
    static String date; //in format of MM/DD/YYYY
    static String start; //start time
    static String end; //end time
    static String descript;
    static String location;
    static int type;
    static boolean validEventType = false;
    
    
    public static void main(String[] args) throws IOException {

	clearScreen();
	loadApp();
	
	clearScreen();
	System.out.println("Thank you for using Social.ly!");


    }

    //method to clear the console
    public static void clearScreen() {  
	System.out.print("\033[H\033[2J");  
	System.out.flush();  

	System.out.println("+++++++++++++++++++++++++++++\n\n     SOCIAL.LY     \ncopyright 2019, HopTrack Gang\n+++++++++++++++++++++++++++++\n\n");
    }

    //method to print error message: invalid entry
    public static void msgError() {
	System.out.println("Invalid input!");
	System.out.println("");
    }


    //method to show user location
    public static void showLoctn(int aChoice) throws IOException {
	clearScreen();

	if(aChoice == 0){
	    System.out.println("-----Event Joiner-----\n\nEnter the unique identifier of the event you wish to join (or -1 to quit the process)\n\n");
	    joinEvent();
	    
	}
	else if(aChoice == 1) {
	    System.out.println("Home* --> (1)\nAdd event --> (2)\nSearch events --> (3)\nMy profile --> (4)\nJoin Group -->(0)\nQuit --> (-1)\n\n");
	}
	else if(aChoice == 2) {
	    System.out.println("-----Event Adder----- \n\nBack --> (-1)\n\n");
	    createEvent();
	}
	else if(aChoice == 3) {
	    System.out.println("Home --> (1)\nAdd event --> (2)\nSearch events* --> (3)\nMy profile --> (4)\nJoin Group -->(0)\nQuit --> (-1)\n\n");
	    printSearchOptions();
	}
	else if(aChoice == 4) {
	    System.out.println("Home --> (1)\nAdd event --> (2)\nSearch events --> (3)\nMy profile* --> (4)\nJoin Group -->(0)\nQuit --> (-1)\n\n");
	    User.printToString();
	    User.printUserOptions();

	}
    }
    
    public static void joinEvent() throws IOException{
		Scanner justin = new Scanner(System.in);
	int tempID = justin.nextInt();
	if(tempID < 0){
	    clearScreen();
	    state = 1;
	    showLoctn(1);
	    return;
	}
	User.addEvent(tempID);
	Event.addMember(tempID, User.getUID());

	clearScreen();
	showLoctn(1);
	state = 1;
	System.out.println("You have been added to the event!");
    }

    public static void printSearchOptions(){

	System.out.println("Study (5)\nClubs (6)\nVideo Games (7)\nFood (8)\nSocial (9)\n\n");
	System.out.print("Select a category: ");

    }


    public static void createEvent() throws IOException{
	validEventType = false;
	System.out.print("Please enter the following:\nEvent title: ");	
	scan.nextLine();
	title = scan.nextLine();
	
	try{
	    if(Integer.parseInt(title) == -1){
		clearScreen();
		state = 1;
		showLoctn(1);
		return;
	    }
	}
	catch(NumberFormatException e){

	}
	
	System.out.print("Date (in the format of MM/DD/YYYY): ");
	date = scan.next();
	
	try{
	    if(Integer.parseInt(date) == -1){
		clearScreen();
		state = 1;
		showLoctn(1);
		return;
	    }
	}
	catch(NumberFormatException e){

	}

	System.out.print("Start time: ");
	start = scan.next();

	try{
	    if(Integer.parseInt(start) == -1){
		clearScreen();
		state = 1;
		showLoctn(1);
		return;
	    }
	}
	catch(NumberFormatException e){

	}
	
	System.out.print("End time: ");
	end = scan.next();

	try{
	    if(Integer.parseInt(end) == -1){
		clearScreen();
		state = 1;
		showLoctn(1);
		return;
	    }
	}
	catch(NumberFormatException e){

	}
	
	System.out.print("Event description: ");
	scan.nextLine();
	descript = scan.nextLine();
	
	try{
	    if(Integer.parseInt(descript) == -1){
		clearScreen();
		state = 1;
		showLoctn(1);
		return;
	    }
	}
	catch(NumberFormatException e){

	}
	
	System.out.print("Location: ");
	location = scan.nextLine();

	try{
	    if(Integer.parseInt(location) == -1){
		clearScreen();
		state = 1;
		showLoctn(1);
		return;
	    }
	}
	catch(NumberFormatException e){

	}

	while(!validEventType) {
	    System.out.println("Event type:\n*Study -> 1\n*Clubs -> 2\n*Video Games -> 3\n*Food -> 4\n*Social -> 5\n");
	    type = scan.nextInt();
	    if(type != 1 && type != 2 && type != 3 && type != 4 && type != 5 && type != -1) {
		msgError();
	    }
	    else {
		validEventType = true;
	    }
	    if(type == -1){

		clearScreen();
		state = 1;
		showLoctn(1);
		return;

	    }
	}
	
	Event event = new Event(title, User.getName(), date, start, end, descript, location, type);

	User.addEvent(Event.getID());

	clearScreen();
	state = 1;
	showLoctn(1);
	System.out.println("Event created successfully!");

	
    }
    public static void loadApp() throws FileNotFoundException, IOException{
	
	//ENTRY PAGE
	System.out.print("Hello, Welcome to Social.ly! ");
	while(!validInput) {
	    System.out.println("Please select an option:\n *Log in -> enter 0\n *Create account -> enter 1");	    
	    entry = scan.nextInt();
	    
	    if(entry == 0) {
		while(!validUser){
		    System.out.print("Enter your username: ");
		    username = scan.next();
		    System.out.print("Enter your password: ");
		    password = scan.next();
		    validUser = User.verifyUser(username, password);
		}
		validInput = true;
            }
            else if (entry == 1) {
		System.out.print("Enter your name: ");
		scan.nextLine();
                name = scan.nextLine();

		System.out.print("Enter a username: ");
		while(true){
		    username = scan.next();   
		    String checkName = ("user" + username + ".txt");
		    File check = new File(checkName);
		    if(check.exists()){
			System.out.println("Username taken :(\nEnter a different username:");
			continue;
		    }
		    break;
		}

		System.out.print("Enter a password: ");
		password = scan.next();
		while(!validSchool) {
		    System.out.println("Enter a school:\n *Johns Hopkins University -> enter 1\n *University of Maryland -> enter 2");
		    entry = scan.nextInt();
		    if(entry == 1 || entry == 2) {
			school = entry;
			validSchool = true;
		    }
		    else {
			clearScreen();
			System.out.println("Your name: " + name);
			System.out.println("Your username: " + username);
			System.out.println("Your password: " + password);
			System.out.println("");
			msgError();
		    }
		}
		System.out.print("Enter an email: ");
		email = scan.next();
		
		
                User temp = new User(username, password, school, email,  name);
		
		validInput = true;    
		clearScreen();
		System.out.println("Welcome, " + name + ", to Social.ly!");
	    }
	    else if(entry == -1){
		return;
	    }


	    if(!validInput) {
		clearScreen();
		msgError();
	    }
	}

	done= false;
	state = 1;
	boolean clear = true;
	//cyclic state until user manually exits
	//FIRST ITERATION STARTS AT HOME PAGE
	
	System.out.println("Enter a number to navigate the app. The * indicates where you are right now:");
	showLoctn(state);

	while(!done){
	    clear = true;
	    validInput = false;
	    boolean validCheck = false;	    
	    
	    choice = scan.nextInt();
	    while(!validCheck) {
		
		if(state != 3 && state != 4){

		    switch(choice){
			
		    case -1:
			done = true;
			clearScreen();
			return;

		    case 0:
			validCheck = true;
			state = 0;
			break;
			
		    case 1:
			validCheck = true;
			state = 1;
			break;
			    
		    case 2:
			validCheck = true;
			state = 2;
			break;

		    case 3:
			validCheck = true;
			state = 3;
			break;
			
		    case 4:
			validCheck = true;
			state = 4;
			break;
   
		    default:
			clearScreen();
			msgError();
			System.out.println("Enter a number to navigate the app. The * indicates where you are right now:");
			System.out.println("Home* --> (1)\nAdd event --> (2)\nSearch events --> (3)\nMy profile --> (4)\nJoin Group -->(0)");
			choice = scan.nextInt();
			break;
		    }
		    
		}
		//explore events
		else if(state == 3){
		    
		    ArrayList<Integer> founds = new ArrayList<Integer>();
		    
		    switch(choice){
			
		    case -1:
			done = true;
			clearScreen();
			return;
			
		    case 0:
			validCheck = true;
			state = 0;
			break;

		    case 1:
			validCheck = true;
			state = 1;
			break;
			    
		    case 2:
			validCheck = true;
			state = 2;
			break;

		    case 3:
			validCheck = true;
			state = 3;
			break;
			
		    case 4:
			validCheck = true;
			state = 4;
			break;
		    
		    case 5:
			validCheck = true;
			Event.exploreEvent(1, founds);
			clear = false;
			break;

		    case 6:
			validCheck = true;
			Event.exploreEvent(2, founds);
			clear = false;
			break;

		    case 7:
			validCheck = true;
			Event.exploreEvent(3, founds);
			clear = false;
			break;

		    case 8:
			validCheck = true;
			Event.exploreEvent(4, founds);
			clear = false;
			break;
			
		    case 9:
			validCheck = true;
			Event.exploreEvent(5, founds);
			clear = false;
			break;
			
		    default:
			clearScreen();
			msgError();
			System.out.println("Enter a number to navigate the app. The * indicates where you are right now:");
			System.out.println("Home* --> (1)\nAdd event --> (2)\nSearch events --> (3)\nMy profile --> (4)\nJoin Group --> (0)\n");
			choice = scan.nextInt();
		    }
		    
		    if(!founds.isEmpty()){
			for(int i = 0; i < founds.size(); i++){
			    System.out.println(Event.returnString(founds.get(i)) + "\n");			    
			}
		    }
		    else{
			System.out.println("No results found :(");
		    }
		}

		//user profile page
		else if(state == 4){
		    
		    switch(choice){
			
		    case -1:
			done = true;
			clearScreen();
			return;
		    
		    case 0:
			validCheck = true;
			state = 0;
			break;

		    case 1:
			validCheck = true;
			state = 1;
			break;
			    
		    case 2:
			validCheck = true;
			state = 2;
			break;

		    case 3:
			validCheck = true;
			state = 3;
			break;
			
		    case 4:
			validCheck = true;
			state = 4;
			break;
		    
		    case 5:
			validCheck = true;
			User.editProfile();
			break;

		    case 6:
			validCheck = true;
			User.logout();
			state = -1;
			break;
			
		    default:
			clearScreen();
			msgError();
			System.out.println("Enter a number to navigate the app. The * indicates where you are right now:");
			System.out.println("Home* --> (1)\nAdd event --> (2)\nSearch events --> (3)\nMy profile --> (4)\nJoin Group --> (0)\n ");
			choice = scan.nextInt();
		    }
		    


		}

		if(clear){
		    showLoctn(state);
		}
	    }
	    
	}
	
    }
    
}
