//User.java
//The basic user class
package EventTracker;

//stream objects
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.File;
//exceptions
import java.io.IOException;
import java.io.FileNotFoundException;

//container
import java.util.ArrayList;


public class User {
    private static ArrayList<Integer> events = new ArrayList<>();
    private static String username = "";
    private static String password = "";
    private static int school = -1;
    private static String schoolName = "";
    private static String email = "";
    private static String name = "";
    private static int uID = -1;
    private static int numEvents = 0;
    
    private String temporary;
    private static int currentID;

    public static String getName(){
	return name;
    }

    

    //constructor
    public User(String username, String password, int school, String email, String name) throws IOException{
	User.username = username;
	User.password = password;
	User.school = school;
	User.email = email;
	User.name = name;
	
	setSchool();

	createNewUserFile();

    }


    private static void printToFile() throws IOException{

	String temporary = ("user" + User.username + ".txt");

	FileOutputStream outFileByteStream = new FileOutputStream(temporary);	
	PrintWriter outFS = new PrintWriter(outFileByteStream);
	
	outFS.printf("%s %s %d %s %d %s\n%d ", User.username, User.password, User.school, User.email, User.uID, User.name, numEvents); 
	if(User.numEvents > 0) {
	    int i = 0;
	    while(i < User.numEvents) {
		outFS.printf("%d ", User.events.get(i));
		i++;
	    }
	}
	
	outFS.flush();
	outFS.close();
       

    }

    private static void createNewUserFile() throws IOException{

	FileInputStream inFileByteStream = new FileInputStream("numUser.txt");
	Scanner outIS = new Scanner(inFileByteStream);	
	User.currentID = outIS.nextInt();
	User.uID = User.currentID;

	printToFile();

	FileOutputStream userNumByteStream = new FileOutputStream("numUser.txt");
	PrintWriter userNumPW = new PrintWriter(userNumByteStream, false);
	userNumPW.print(++User.currentID);

	userNumPW.flush();
	userNumPW.close();

	outIS.close();

    }

    private static void setSchool(){
	switch(User.school){
	    
	case 1:
	    User.schoolName = "Johns Hopkins";
	    break;
	    
	case 2:
	    User.schoolName = "University of Maryland";
	    break;
	    
	default:
	    User.schoolName = "NaN";
	    break;
	}
	
    }
    
    
    //adds event to user profile
    public static void addEvent(int event) throws IOException {
	User.events.add(event);
	User.numEvents++;
	User.printToFile();
    }
    
    //checks user files to see if username and password are valid
    public static boolean verifyUser(String aUsername, String aPassword) throws FileNotFoundException{

	String fileName = ("user" + aUsername + ".txt");
	FileInputStream check;

	try {
	    check = new FileInputStream(fileName);
	
	}

	catch (FileNotFoundException e) {
	    Main.clearScreen();
	    System.out.println("It seems like that username doesn't exist");
	   
	    return false;

	}

	readIn(check);
	
	
	if (User.username.equals(aUsername) && User.password.equals(aPassword)){
	    Main.clearScreen();
	    System.out.println("Welcome back" + User.name + "!");
	    return true;
	}
	else {
	    Main.clearScreen();
	    System.out.println("Your username and password do not match, please try again");
	    return false;
	}
	
    }
    
    //imports user information from a data file
    private static void readIn(FileInputStream input) {

	Scanner userScan = new Scanner(input);

	User.username = userScan.next();
	User.password = userScan.next();
	User.school = userScan.nextInt();
	User.email = userScan.next();
	User.uID = userScan.nextInt();
	User.name = userScan.nextLine();
	User.numEvents = userScan.nextInt();
	if(User.numEvents > 0) {
	    int i = 0;
	    while(i < User.numEvents) {
		User.events.add(userScan.nextInt());
		i++;
	    }
	}
	
	setSchool();

	userScan.close();

    }

    //displays all the user's information
    public static void printToString() throws IOException {

	System.out.println("Name: " + User.name + "\n");
	System.out.println("Username: " + User.username + "\n");
	System.out.println("Password: **hidden**\n");
	System.out.println("Email: " + User.email + "\n");
	System.out.println("School: " + User.schoolName + "\n");
	System.out.println("Friend Code: " + User.uID + "\n");
	System.out.println("My Events:\n ");

	FileInputStream readMyEvent = new FileInputStream("user" + User.username + ".txt");
	Scanner readAgain = new Scanner(readMyEvent);

	readAgain.nextLine();
	int stop = readAgain.nextInt();
	int evnt;
	String outty = "";
	for(int i = 0; i < stop; i++) {
	    evnt = readAgain.nextInt();
	    outty = Event.returnString(evnt);
	    System.out.print("\n" + outty + "\n");
	}
	
	readAgain.close();
    }
    
    //prints the editable info with option tags
    public static void printEditOptions(){

	System.out.println("Name: " + User.name + " (1)\n");
	System.out.println("Username: " + User.username + " (2)\n");
	System.out.println("Password: **hidden** (3)\n");
	System.out.println("Email: " + User.email + " (4)\n");
	System.out.println("School: " + User.schoolName + " (5)\n");

    }

    public static void printUserOptions(){

	System.out.println("\nEdit profile (5)\nLog Out (6)");

    }


    //edits profile
    public static void editProfile() throws IOException{
		
	Main.clearScreen();

	Scanner choice = new Scanner(System.in);
	int select = 0;
	boolean stillGoing = true;

	boolean userChange = false;
	String oldUserName = User.username;
	boolean clearCase = false;
	
	while(stillGoing) {
	    clearCase = false;
	    System.out.println("\n   ----PROFILE EDITOR----\n");
	    printEditOptions();
	    System.out.println("Enter the number of the field you'd like to change (enter (0) when finished)\n");
	
	    select = choice.nextInt();
	    choice.nextLine();

	    switch(select) {

	    case 0:
		stillGoing = false;
		break;

	    case 1: 
		System.out.println("Enter your new name: ");
		User.name = choice.nextLine();
		break;

	    case 2:
		System.out.println("Enter your new username: ");

		while(true){
		    User.username = choice.next();   
		    String checkName = ("user" + User.username + ".txt");
		    File check = new File(checkName);
		    if(check.exists()){
			System.out.println("Username taken :(\nEnter a different username");
			continue;
		    }
		    break;
		}

		userChange = true;
		break;

	    case 3:
		System.out.println("Enter your old password: ");
		
		if(!User.password.equals(choice.next())){
		    clearCase = true;
		    System.out.println("Incorrect password");
		    break;
		}
			
		System.out.println("Enter your new password: ");
		String pass = choice.next();

		System.out.println("Confirm your new password: ");

		if(pass.equals(choice.next())){
		    User.password = pass;
		    break;
		} else {
		    clearCase = true;
		    System.out.println("New password doesn't match confirmation");
		    break;
		}
		
	    case 4:
		System.out.println("Enter your new email: ");
		User.email = choice.next();
		break;

	    case 5:
		System.out.println("Choose your new school:\nJohns Hopkins (1) \nUniversity of Maryland (2)");
		User.school = choice.nextInt();
		setSchool();
		break;

	    default:
		System.out.println("Invalid entry");
		clearCase = true;
		break;

	    }
	    if(!clearCase) {
		Main.clearScreen();
	    }
	}
	
	if(userChange){
	    String toRemove = ("user" + oldUserName + ".txt");
	    File removing = new File(toRemove);
	    removing.delete();

	}

	printToFile();

	Main.clearScreen();
	printToString();

	System.out.println("Your profile has been updated!");
    }

    public static void logout() throws FileNotFoundException, IOException{

	User.username = "";
	User.password = "";
	User.school = -1;
	User.schoolName = "";
	User.email = "";
	User.name = "";
	User.uID = -1;
	User.events.removeAll(events);
	Main.validInput = false;
	Main.validUser = false;
	Main.validSchool = false;
	Main.entry = -1;
	Main.choice = 0;
	Main.scan = new Scanner(System.in);
	Main.state = 1;
	Main.done = false;
	Main.clearScreen();
	Main.loadApp();

	////////////////////////resets event variables
	Main.title = "";
	Main.date = ""; //in format of MM/DD/YYYY
	Main.start = ""; //start time
	Main.end = ""; //end time
	Main.descript = "";
	Main.location = "";
	Main.type = -1;
	Main.validEventType = false;

	
	
   }

    public static int getUID(){
	return User.uID;

    }

}

